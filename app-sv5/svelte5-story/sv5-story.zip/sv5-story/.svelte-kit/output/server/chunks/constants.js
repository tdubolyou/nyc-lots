const NO_TRANSLATE_ATTRIBUTE = "data-no-translate";
const LANG_COOKIE_NAME = "paraglide_lang";
export {
  LANG_COOKIE_NAME as L,
  NO_TRANSLATE_ATTRIBUTE as N
};

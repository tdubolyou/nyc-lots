import { i as i18n } from "./i18n.js";
const handleParaglide = i18n.handle();
const handle = handleParaglide;
export {
  handle
};

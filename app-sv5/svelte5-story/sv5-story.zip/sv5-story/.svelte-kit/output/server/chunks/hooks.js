import { i as i18n } from "./i18n.js";
const reroute = i18n.reroute();
export {
  reroute
};

export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set([".DS_Store","Logo_orange_2024_bolder.png","favicon.png","fonts/barlow/Barlow-Black.ttf","fonts/barlow/Barlow-BlackItalic.ttf","fonts/barlow/Barlow-Bold.ttf","fonts/barlow/Barlow-BoldItalic.ttf","fonts/barlow/Barlow-ExtraBold.ttf","fonts/barlow/Barlow-ExtraBoldItalic.ttf","fonts/barlow/Barlow-ExtraLight.ttf","fonts/barlow/Barlow-ExtraLightItalic.ttf","fonts/barlow/Barlow-Italic.ttf","fonts/barlow/Barlow-Light.ttf","fonts/barlow/Barlow-LightItalic.ttf","fonts/barlow/Barlow-Medium.ttf","fonts/barlow/Barlow-MediumItalic.ttf","fonts/barlow/Barlow-Regular.ttf","fonts/barlow/Barlow-SemiBold.ttf","fonts/barlow/Barlow-SemiBoldItalic.ttf","fonts/barlow/Barlow-Thin.ttf","fonts/barlow/Barlow-ThinItalic.ttf","mapTO-light.json","splash_bg.png","splash_img.jpg"]),
	mimeTypes: {".png":"image/png",".ttf":"font/ttf",".json":"application/json",".jpg":"image/jpeg"},
	_: {
		client: {"start":"_app/immutable/entry/start.4botqkQJ.js","app":"_app/immutable/entry/app.C2nJQk8Z.js","imports":["_app/immutable/entry/start.4botqkQJ.js","_app/immutable/chunks/entry.CDNgVnRy.js","_app/immutable/chunks/index-client.mYbAdY7z.js","_app/immutable/entry/app.C2nJQk8Z.js","_app/immutable/chunks/i18n.DlhDyJ3a.js","_app/immutable/chunks/legacy.uz8oV-dB.js","_app/immutable/chunks/index-client.mYbAdY7z.js","_app/immutable/chunks/entry.CDNgVnRy.js","_app/immutable/chunks/render.D2ikVlTS.js","_app/immutable/chunks/props.CefR5zOq.js","_app/immutable/chunks/this.8mx6tFvo.js"],"stylesheets":[],"fonts":[],"uses_env_dynamic_public":false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();

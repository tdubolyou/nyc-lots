

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.CxHW48z-.js","_app/immutable/chunks/legacy.uz8oV-dB.js","_app/immutable/chunks/index-client.mYbAdY7z.js","_app/immutable/chunks/props.CefR5zOq.js","_app/immutable/chunks/render.D2ikVlTS.js","_app/immutable/chunks/index.Djl9S8hi.js","_app/immutable/chunks/this.8mx6tFvo.js","_app/immutable/chunks/lifecycle.DOIXaxwN.js"];
export const stylesheets = ["_app/immutable/assets/2.CjxGmBao.css"];
export const fonts = ["_app/immutable/assets/barlow-vietnamese-400-normal.B8B3d_DU.woff2","_app/immutable/assets/barlow-vietnamese-400-normal.Dcxa7Lg7.woff","_app/immutable/assets/barlow-latin-ext-400-normal.DsA6LmuC.woff2","_app/immutable/assets/barlow-latin-ext-400-normal.DGsTVCL_.woff","_app/immutable/assets/barlow-latin-400-normal.CtwdMZP0.woff2","_app/immutable/assets/barlow-latin-400-normal.Gqj0RTbC.woff","_app/immutable/assets/barlow-condensed-vietnamese-400-normal.CwVqPvxH.woff2","_app/immutable/assets/barlow-condensed-vietnamese-400-normal.CBQAS5EK.woff","_app/immutable/assets/barlow-condensed-latin-ext-400-normal.DsWpmWy3.woff2","_app/immutable/assets/barlow-condensed-latin-ext-400-normal.B_amEQ8e.woff","_app/immutable/assets/barlow-condensed-latin-400-normal.CSL47Yq5.woff2","_app/immutable/assets/barlow-condensed-latin-400-normal.DijiFCtA.woff"];

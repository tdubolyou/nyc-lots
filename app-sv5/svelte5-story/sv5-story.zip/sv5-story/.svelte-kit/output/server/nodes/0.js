

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.sEvUVsrH.js","_app/immutable/chunks/legacy.uz8oV-dB.js","_app/immutable/chunks/index-client.mYbAdY7z.js","_app/immutable/chunks/i18n.DlhDyJ3a.js","_app/immutable/chunks/entry.CDNgVnRy.js","_app/immutable/chunks/props.CefR5zOq.js","_app/immutable/chunks/lifecycle.DOIXaxwN.js","_app/immutable/chunks/index.Djl9S8hi.js"];
export const stylesheets = ["_app/immutable/assets/0.DDNVUhW1.css"];
export const fonts = [];

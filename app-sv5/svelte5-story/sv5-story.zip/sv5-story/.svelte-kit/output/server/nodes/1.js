

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.DJDBqQi0.js","_app/immutable/chunks/legacy.uz8oV-dB.js","_app/immutable/chunks/index-client.mYbAdY7z.js","_app/immutable/chunks/render.D2ikVlTS.js","_app/immutable/chunks/lifecycle.DOIXaxwN.js","_app/immutable/chunks/entry.CDNgVnRy.js"];
export const stylesheets = [];
export const fonts = [];

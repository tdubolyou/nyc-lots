import { P as push, R as pop, T as ensure_array_like, $ as stringify, W as bind_props } from "../../chunks/index.js";
import { g as getTranslationFunctions, a as attr } from "../../chunks/index2.js";
import "clsx";
import "d3";
import { e as escape_html } from "../../chunks/escaping.js";
import "maplibre-gl";
function BoroChart($$payload, $$props) {
  push();
  $$payload.out += `<div class="chart-container svelte-10cyovc"></div>`;
  pop();
}
function Sidebar($$payload, $$props) {
  push();
  let flyTo = $$props["flyTo"];
  let sidebarVisible = true;
  const componentMap = {
    BoroChart
    // Add additional chart/component mappings here if needed.
  };
  let sections = [
    {
      title: "How Many parking lots are there in NYC?",
      content: [
        {
          type: "text",
          value: "There are a lot. I narrowed it down to lots within 800m of subway stations that were in both the PLUTO database and the City of NYC mapping. Having said that it's not as many as I might have thought. Let's have a look."
        },
        { type: "chart", component: "BoroChart" },
        {
          type: "text",
          value: "Across all 5 boroughs there are XXX parking lots. The breakdown by borough is as shown below. XX has the most, and XX has the least. Spatially, they are generally distributed around the outsides of the subway network."
        }
      ],
      coordinates: [-73.856077, 40.848447],
      zoomLevel: 14,
      isCollapsed: true
    },
    {
      title: "Data Sources",
      content: [
        {
          type: "text",
          value: "Details about data sources."
        }
      ],
      coordinates: [-73.856077, 40.848447],
      zoomLevel: 16,
      isCollapsed: true
    },
    {
      title: "Analysis",
      content: [
        {
          type: "text",
          value: "Analysis of the map data."
        }
      ],
      coordinates: [-73.856077, 40.848447],
      zoomLevel: 15,
      isCollapsed: true
    },
    {
      title: "Conclusion",
      content: [
        {
          type: "text",
          value: "Final thoughts and conclusions."
        }
      ],
      coordinates: [-73.856077, 40.848447],
      zoomLevel: 13,
      isCollapsed: true
    }
  ];
  const paraglide_sveltekit_translate_attribute_pass_translationFunctions = getTranslationFunctions();
  const [
    paraglide_sveltekit_translate_attribute_pass_translateAttribute,
    paraglide_sveltekit_translate_attribute_pass_handle_attributes
  ] = paraglide_sveltekit_translate_attribute_pass_translationFunctions;
  const each_array = ensure_array_like(sections);
  $$payload.out += `<div${attr("class", `sidebar ${stringify("")} svelte-ih2hs7`)}${attr("aria-hidden", !sidebarVisible)}><button class="collapse-button svelte-ih2hs7" aria-label="Close sidebar">×</button> <header class="svelte-ih2hs7"><h1 class="svelte-ih2hs7">How much housing could be built on the parking lots of NYC?</h1> <h2 class="svelte-ih2hs7">A lot, actually</h2> <p class="svelte-ih2hs7">By: <a${attr("href", paraglide_sveltekit_translate_attribute_pass_translateAttribute(`https://www.tomweatherburn.com/`, void 0))} target="_blank" class="svelte-ih2hs7">Tom Weatherburn</a></p></header> <!--[-->`;
  for (let index = 0, $$length = each_array.length; index < $$length; index++) {
    let section = each_array[index];
    $$payload.out += `<div class="section"><h3 class="section-header svelte-ih2hs7"${attr("aria-expanded", !section.isCollapsed)}><span>${escape_html(section.title)}</span> <span class="chevron-icon svelte-ih2hs7">`;
    if (section.isCollapsed) {
      $$payload.out += "<!--[-->";
      $$payload.out += `<svg width="12" height="12" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 3L5 7L9 3" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
    } else {
      $$payload.out += "<!--[!-->";
      $$payload.out += `<svg width="12" height="12" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 7L5 3L9 7" stroke="black" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;
    }
    $$payload.out += `<!--]--></span></h3> `;
    if (!section.isCollapsed) {
      $$payload.out += "<!--[-->";
      const each_array_1 = ensure_array_like(section.content);
      $$payload.out += `<div><!--[-->`;
      for (let $$index = 0, $$length2 = each_array_1.length; $$index < $$length2; $$index++) {
        let block = each_array_1[$$index];
        if (block.type === "text") {
          $$payload.out += "<!--[-->";
          $$payload.out += `<p>${escape_html(block.value)}</p>`;
        } else {
          $$payload.out += "<!--[!-->";
          if (block.type === "chart") {
            $$payload.out += "<!--[-->";
            $$payload.out += `<div class="chart-container"><!---->`;
            componentMap[block.component]?.($$payload, {});
            $$payload.out += `<!----></div>`;
          } else {
            $$payload.out += "<!--[!-->";
          }
          $$payload.out += `<!--]-->`;
        }
        $$payload.out += `<!--]-->`;
      }
      $$payload.out += `<!--]--></div>`;
    } else {
      $$payload.out += "<!--[!-->";
    }
    $$payload.out += `<!--]--></div>`;
  }
  $$payload.out += `<!--]--></div> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { flyTo });
  pop();
}
function Map($$payload, $$props) {
  push();
  $$payload.out += `<div id="map" class="svelte-11rimeu"></div>`;
  pop();
}
function Splash_($$payload, $$props) {
  push();
  let onClose = $$props["onClose"];
  const paraglide_sveltekit_translate_attribute_pass_translationFunctions = getTranslationFunctions();
  const [
    paraglide_sveltekit_translate_attribute_pass_translateAttribute,
    paraglide_sveltekit_translate_attribute_pass_handle_attributes
  ] = paraglide_sveltekit_translate_attribute_pass_translationFunctions;
  if (onClose) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<div class="splash svelte-1yszbcq"><div class="background svelte-1yszbcq"></div> <div class="overlay svelte-1yszbcq"><div class="title svelte-1yszbcq">The Parking Lots of NYC</div> <div class="subtitle svelte-1yszbcq">How Much Housing Could Be Built On Surface Lots Near Transit?</div> <div class="byline svelte-1yszbcq">By: <a${attr("href", paraglide_sveltekit_translate_attribute_pass_translateAttribute(`https://tomweatherburn.com`, void 0))} target="_blank" class="svelte-1yszbcq">Tom Weatherburn</a></div> <div class="image-container svelte-1yszbcq"><img src="/splash_img.jpg" alt="Splash Image" class="svelte-1yszbcq"> <button class="enter-button svelte-1yszbcq">ENTER MAP</button></div> <p class="svelte-1yszbcq">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque fermentum commodo neque, at bibendum massa blandit a.
        Vivamus sed aliquam velit. Sed eget justo et diam fermentum scelerisque quis a nibh.</p> <p class="svelte-1yszbcq">Fusce at augue ac nisl viverra tempus. Suspendisse in sagittis libero. Integer in leo justo. Vestibulum in tristique neque.
        Praesent tincidunt consectetur feugiat.</p> <p class="svelte-1yszbcq">Curabitur fermentum nunc a diam pharetra, at sodales turpis aliquet. Integer iaculis odio ac leo pellentesque, sed accumsan
        ipsum efficitur. Donec sit amet odio nec nulla semper vehicula.

        Laboris minim reprehenderit magna eu voluptate non id elit ipsum. Eu fugiat laboris irure ad aute nostrud velit amet anim anim. Ullamco exercitation aliqua dolore ullamco ea. Tempor quis minim ea aliquip. Dolor veniam sit do commodo fugiat consectetur magna officia. Amet reprehenderit velit aliqua non minim dolore sint duis in.

        Est nulla exercitation enim elit dolor. Labore laborum elit commodo eiusmod pariatur non dolor fugiat consectetur in velit do minim. Veniam adipisicing in ea laboris est.

        Eu elit nulla ex fugiat deserunt excepteur labore nostrud ad. Consectetur nulla Lorem reprehenderit adipisicing dolore id dolore sit veniam ex aliqua irure qui. Consequat aliquip laboris sint laboris reprehenderit reprehenderit id magna consectetur laborum ad velit Lorem duis. Laborum sint est quis exercitation non magna sint Lorem labore occaecat esse sint dolor.

        Incididunt adipisicing eiusmod do quis qui sit. Nulla nostrud esse aliquip aute est nostrud commodo eu qui eiusmod ad. Ipsum non fugiat aute dolore. Anim veniam sunt eu ea enim aliquip qui elit adipisicing. Id consequat amet sint reprehenderit quis. Anim ea Lorem consectetur est cupidatat aute laborum do cupidatat.</p></div></div>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { onClose });
  pop();
}
function _page($$payload) {
  let showSplash = true;
  function flyTo(coordinates = [-79.3832, 43.6532], zoomLevel = 14) {
    {
      console.error("Map reference is not set properly or does not have the flyTo method");
    }
  }
  function closeSplash() {
    showSplash = false;
  }
  $$payload.out += `<div class="app svelte-1yskxyi">`;
  if (showSplash) {
    $$payload.out += "<!--[-->";
    Splash_($$payload, { onClose: closeSplash });
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> <div${attr("class", `map-container ${stringify(showSplash ? "" : "visible")} svelte-1yskxyi`)}>`;
  Map($$payload);
  $$payload.out += `<!----></div> `;
  if (!showSplash) {
    $$payload.out += "<!--[-->";
    Sidebar($$payload, { flyTo });
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></div>`;
}
export {
  _page as default
};
